document.getElementById("saveKey").textContent = chrome.i18n.getMessage("saveBtn");
document.getElementById("saveTag").textContent = chrome.i18n.getMessage("saveBtn");

document.getElementById("apiUrl").placeholder = chrome.i18n.getMessage("placeApiUrl");
document.getElementById("apiTokens").placeholder = chrome.i18n.getMessage("placeApiTokens");
document.getElementById("content").placeholder = chrome.i18n.getMessage("placeContent");

document.getElementById("content_submit_text").textContent = chrome.i18n.getMessage("submitBtn");

document.getElementById("hideInput").placeholder = chrome.i18n.getMessage("placeHideInput");
document.getElementById("showInput").placeholder = chrome.i18n.getMessage("placeShowInput");